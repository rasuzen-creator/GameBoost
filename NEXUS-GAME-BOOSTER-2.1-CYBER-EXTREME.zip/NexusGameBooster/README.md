# NEXUS GAME BOOSTER 2.1 — CYBER EXTREME

Native Android app built with Kotlin and Jetpack Compose.

## 2.1 update
- Larger, clearer dashboard and Performance Lab.
- RAM history line chart (up to 40 readings).
- Device telemetry refreshes every 3 seconds while the app is active.
- Floating HUD refreshes every 3 seconds and includes a visible X close button.
- HUD can also be stopped from its persistent notification.
- HUD header can be dragged to reposition the panel.

## Build
Open this folder in Android Studio and build `app:assembleDebug`, or use the GitHub Actions workflow in the repository.

## Android limitations
Regular third-party apps cannot reliably read another game's private FPS/GPU telemetry, force CPU/GPU clocks, or terminate other apps. This app displays only values available through public Android APIs. Battery temperature is the battery sensor reading, not CPU temperature.
