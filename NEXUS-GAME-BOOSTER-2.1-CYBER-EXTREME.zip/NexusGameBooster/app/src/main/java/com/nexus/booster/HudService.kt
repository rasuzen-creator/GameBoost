package com.nexus.booster

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Floating monitor. X closes the overlay and stops this service immediately. */
class HudService : Service() {
    private var window: WindowManager? = null
    private var panel: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var readout: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            refreshReadout()
            handler.postDelayed(this, 3000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val channelId = "nexus_hud"
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(channelId, "NEXUS Gaming HUD", NotificationManager.IMPORTANCE_LOW))
        }
        startForeground(71, buildNotification(channelId))
        if (Settings.canDrawOverlays(this)) showPanel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(channelId: String): Notification {
        val stopIntent = Intent(this, HudService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 72, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("NEXUS Gaming HUD faol")
            .setContentText("HUD'ni to‘xtatish uchun STOP ni bosing")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "STOP HUD", pending)
            .setOngoing(true).build()
    }

    @Suppress("DEPRECATION")
    private fun overlayWindowType(): Int = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE

    private fun roundedBackground(color: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = 24f
        setStroke(2, stroke)
    }

    private fun showPanel() {
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 15)
            background = roundedBackground(Color.rgb(11, 19, 34), Color.rgb(55, 231, 255))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "NEXUS  /  LIVE MONITOR"
            textSize = 12f
            setTextColor(Color.rgb(55, 231, 255))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        header.addView(brand, LinearLayout.LayoutParams(0, 42, 1f))
        val close = Button(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(Color.WHITE)
            background = roundedBackground(Color.rgb(91, 34, 65), Color.rgb(255, 91, 126))
            setPadding(0, 0, 0, 0)
            minWidth = 48
            minHeight = 42
            setOnClickListener { stopSelf() }
            contentDescription = "Close NEXUS HUD"
        }
        header.addView(close, LinearLayout.LayoutParams(48, 42))
        root.addView(header)

        val metrics = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setLineSpacing(5f, 1f)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setPadding(2, 10, 2, 10)
        }
        readout = metrics
        root.addView(metrics, LinearLayout.LayoutParams(-1, -2))

        val footer = TextView(this).apply {
            text = "Yangilanish: har 3 soniyada  •  X = yopish"
            textSize = 9f
            setTextColor(Color.rgb(145, 160, 184))
            gravity = Gravity.CENTER
            setPadding(0, 5, 0, 0)
        }
        root.addView(footer)

        // Drag the panel by its header; the close button remains independently clickable.
        header.setOnTouchListener { _, event ->
            val lp = params ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { dragX = event.rawX; dragY = event.rawY; originX = lp.x; originY = lp.y; true }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (originX - (event.rawX - dragX).toInt()).coerceAtLeast(0)
                    lp.y = (originY + (event.rawY - dragY).toInt()).coerceAtLeast(0)
                    try { window?.updateViewLayout(root, lp) } catch (_: Exception) { }
                    true
                }
                else -> true
            }
        }

        val lp = WindowManager.LayoutParams(300, WindowManager.LayoutParams.WRAP_CONTENT, overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 14
            y = 160
        }
        params = lp
        panel = root
        try {
            window?.addView(root, lp)
            refreshReadout()
            handler.postDelayed(refreshTask, 3000L)
        } catch (_: Exception) { stopSelf() }
    }

    private var dragX = 0f
    private var dragY = 0f
    private var originX = 0
    private var originY = 0

    private fun refreshReadout() {
        val s = DeviceMonitor.read(this)
        readout?.text = "RAM       ${s.ramPercent}%   •   ${DeviceMonitor.fmt(s.usedRam)} / ${DeviceMonitor.fmt(s.totalRam)}\n" +
            "BO‘SH RAM  ${DeviceMonitor.fmt(s.availableRam)}\n" +
            "BATTERY   ${s.battery}%${if (s.charging) "  ⚡" else ""}\n" +
            "HARORAT   ${"%.1f".format(java.util.Locale.US, s.batteryTemp)} °C\n" +
            "STORAGE   ${DeviceMonitor.fmt(s.storageFree)} bo‘sh\n" +
            "NETWORK   ${s.network}"
    }

    override fun onDestroy() {
        handler.removeCallbacks(refreshTask)
        try { panel?.let { window?.removeView(it) } } catch (_: Exception) { }
        panel = null
        readout = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object { const val ACTION_STOP = "com.nexus.booster.action.STOP_HUD" }
}
